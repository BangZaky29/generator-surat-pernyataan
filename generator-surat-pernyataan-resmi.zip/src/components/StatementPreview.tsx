import React, { useMemo } from 'react';
import { LetterData } from '../types';
import { paginateText } from '../utils/paginateContent';
import DownloadPDFButton from './DownloadPDFButton';

interface Props {
  data: LetterData;
}

const formatDateIndo = (dateStr: string) => {
  if (!dateStr) return '';
  const date = new Date(dateStr);
  return date.toLocaleDateString('id-ID', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
};

const StatementPreview: React.FC<Props> = ({ data }) => {
  // Membagi isi menjadi halaman-halaman
  const pages = useMemo(() => paginateText(data.isi), [data.isi]);
  const formattedDate = formatDateIndo(data.tanggalSurat);

  return (
    <div className="flex flex-col gap-4 items-center">
      {/* Toolbar */}
      <div className="w-full max-w-[210mm] flex justify-between items-center bg-white p-3 rounded-lg border border-gray-200 shadow-sm sticky top-[70px] z-20">
        <span className="text-sm font-medium text-gray-600 pl-2">
          Preview Dokumen | Ukuran A4
        </span>
        <DownloadPDFButton targetId="pdf-content" fileName={`Surat_Pernyataan_${data.nama.replace(/\s+/g, '_')}`} />
      </div>

      {/* Container for PDF Generation */}
      <div id="pdf-content" className="flex flex-col gap-8 w-full items-center pb-20">
        {pages.map((pageContent, index) => {
          const isFirstPage = index === 0;
          const isLastPage = index === pages.length - 1;

          return (
            <div 
              key={index} 
              className="a4-paper bg-white relative text-gray-900 font-serif leading-relaxed"
            >
              {/* === HEADER / KOP SURAT (Only on Page 1) === */}
              {isFirstPage && data.kopSurat.enabled && (
                <div className="border-b-4 border-double border-gray-800 pb-4 mb-8 flex gap-4 items-center">
                  {data.kopSurat.logoUrl && (
                    <img src={data.kopSurat.logoUrl} alt="Logo" className="h-24 w-24 object-contain" />
                  )}
                  <div className="flex-1 text-center">
                    <h2 className="text-xl font-bold uppercase tracking-wide">{data.kopSurat.namaInstansi}</h2>
                    <p className="text-sm mt-1">{data.kopSurat.alamat}</p>
                    <p className="text-sm">{data.kopSurat.kontak}</p>
                  </div>
                </div>
              )}

              {/* === JUDUL SURAT (Only on Page 1) === */}
              {isFirstPage && (
                <div className="text-center mb-8 mt-4">
                  <h1 className="text-lg font-bold uppercase underline decoration-2 underline-offset-4">
                    {data.judulSurat || 'SURAT PERNYATAAN'}
                  </h1>
                  {data.nomorSurat && (
                    <p className="text-sm mt-1 font-semibold">Nomor: {data.nomorSurat}</p>
                  )}
                </div>
              )}

              {/* === IDENTITAS (Only on Page 1) === */}
              {isFirstPage && (
                <div className="mb-6">
                  <p className="mb-4">Yang bertanda tangan di bawah ini:</p>
                  <table className="w-full">
                    <tbody>
                      <tr>
                        <td className="w-40 py-1 align-top">Nama</td>
                        <td className="w-4 py-1 align-top">:</td>
                        <td className="py-1 align-top font-semibold">{data.nama}</td>
                      </tr>
                      <tr>
                        <td className="py-1 align-top">NIK</td>
                        <td className="py-1 align-top">:</td>
                        <td className="py-1 align-top">{data.nik}</td>
                      </tr>
                      <tr>
                        <td className="py-1 align-top">Pekerjaan/Jabatan</td>
                        <td className="py-1 align-top">:</td>
                        <td className="py-1 align-top">{data.pekerjaan}</td>
                      </tr>
                      <tr>
                        <td className="py-1 align-top">Alamat</td>
                        <td className="py-1 align-top">:</td>
                        <td className="py-1 align-top">{data.alamat}</td>
                      </tr>
                    </tbody>
                  </table>
                  <p className="mt-6 mb-2">
                    Dengan ini menyatakan dengan sesungguhnya, bahwa saya:
                  </p>
                </div>
              )}

              {/* === CONTENT OF THE PAGE === */}
              <div className="whitespace-pre-wrap text-justify min-h-[100px]">
                {pageContent}
              </div>
              
              {/* === SIGNATURE SECTION (Only on Last Page) === */}
              {isLastPage && (
                <div className="mt-12 flex flex-col items-end">
                  <div className="text-center w-64 relative">
                    <p className="mb-2">
                      {data.tempatSurat || '.......'}, {formattedDate}
                    </p>
                    <p className="font-semibold mb-4">Yang membuat pernyataan,</p>
                    
                    {/* Area TTD & Stempel */}
                    <div className="relative h-28 w-full flex items-center justify-center my-2">
                      {/* Stempel Layer (Behind) */}
                      {data.stampUrl && (
                        <img 
                          src={data.stampUrl} 
                          alt="Stempel" 
                          className="absolute h-24 w-24 object-contain opacity-80 -rotate-12 left-6 top-1 pointer-events-none mix-blend-multiply" 
                        />
                      )}
                      
                      {/* Signature Layer (Front) */}
                      {data.signatureUrl ? (
                        <img 
                          src={data.signatureUrl} 
                          alt="Tanda Tangan" 
                          className="h-full w-full object-contain relative z-10" 
                        />
                      ) : (
                        <div className="h-full w-full" />
                      )}
                    </div>

                    <p className="font-bold border-b border-black inline-block min-w-[200px] mt-2">
                      {data.nama || '(Nama Lengkap)'}
                    </p>
                  </div>
                </div>
              )}

              {/* Page Number (Visible on Print/PDF) */}
              <div className="absolute bottom-5 right-10 text-xs text-gray-400 no-print">
                 Halaman {index + 1} dari {pages.length}
              </div>

              {/* Divider Indicator for UI Only (Not in PDF export usually if configured right, but helper for preview) */}
              {!isLastPage && (
                 <div className="absolute -bottom-10 left-0 w-full flex justify-center items-center text-xs text-gray-400 pointer-events-none select-none no-print">
                    <span className="bg-gray-100 px-2 border rounded-full shadow-sm">
                      — PEMISAH HALAMAN —
                    </span>
                 </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default StatementPreview;