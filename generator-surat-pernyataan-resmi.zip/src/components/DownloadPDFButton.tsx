import React from 'react';
import { Download } from 'lucide-react';
import { downloadPDF } from '../utils/downloadPDF';

interface Props {
  targetId: string;
  fileName: string;
}

const DownloadPDFButton: React.FC<Props> = ({ targetId, fileName }) => {
  const handleDownload = () => {
    downloadPDF(targetId, fileName);
  };

  return (
    <button
      onClick={handleDownload}
      className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md shadow-sm transition-all text-sm font-medium"
    >
      <Download size={16} />
      <span>Download PDF</span>
    </button>
  );
};

export default DownloadPDFButton;