import React from 'react';
import { FileText } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-white border-b border-gray-200 h-16 flex items-center px-4 md:px-6 fixed top-0 w-full z-30">
      <div className="flex items-center gap-2 text-blue-600">
        <FileText size={28} />
        <h1 className="text-xl font-bold tracking-tight text-gray-800">
          Statement<span className="text-blue-600">Gen</span>
        </h1>
      </div>
      <div className="ml-auto text-sm text-gray-500 hidden sm:block">
        Generator Surat Pernyataan
      </div>
    </header>
  );
};

export default Header;