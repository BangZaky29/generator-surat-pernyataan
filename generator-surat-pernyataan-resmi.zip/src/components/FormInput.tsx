import React from 'react';
import { LetterData } from '../types';
import KopSurat from './KopSurat';
import TTDUpload from './TTDUpload';
import StampUpload from './StampUpload';
import { User, MapPin, FileType, Calendar, FileText } from 'lucide-react';

interface Props {
  data: LetterData;
  onChange: (data: LetterData) => void;
}

const FormInput: React.FC<Props> = ({ data, onChange }) => {
  const handleChange = (field: keyof LetterData, value: string) => {
    onChange({ ...data, [field]: value });
  };

  return (
    <div className="w-full max-w-2xl mx-auto space-y-6 pb-24 md:pb-10">
      {/* 1. KOP SURAT */}
      <KopSurat 
        data={data.kopSurat} 
        onChange={(kopData) => onChange({ ...data, kopSurat: kopData })} 
      />

      {/* 2. IDENTITAS DIRI */}
      <div className="bg-white p-5 rounded-lg border border-gray-200 shadow-sm space-y-4">
        <h3 className="font-semibold text-lg text-gray-800 flex items-center gap-2 border-b pb-2">
          <User className="text-blue-600" size={20} /> Identitas Pembuat Pernyataan
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1">
            <label className="text-xs font-medium text-gray-500 uppercase">Nama Lengkap</label>
            <input
              type="text"
              value={data.nama}
              onChange={(e) => handleChange('nama', e.target.value)}
              className="w-full p-2.5 bg-gray-50 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
              placeholder="Contoh: Budi Santoso"
            />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-medium text-gray-500 uppercase">NIK <span className="text-red-500">*</span></label>
            <input
              type="text"
              value={data.nik}
              onChange={(e) => handleChange('nik', e.target.value.replace(/\D/g, ''))} // Numeric only
              maxLength={16}
              className="w-full p-2.5 bg-gray-50 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
              placeholder="16 Digit NIK"
            />
          </div>
        </div>

        <div className="space-y-1">
          <label className="text-xs font-medium text-gray-500 uppercase">Pekerjaan / Jabatan <span className="text-red-500">*</span></label>
          <input
            type="text"
            value={data.pekerjaan}
            onChange={(e) => handleChange('pekerjaan', e.target.value)}
            className="w-full p-2.5 bg-gray-50 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
            placeholder="Contoh: Karyawan Swasta"
          />
        </div>

        <div className="space-y-1">
          <label className="text-xs font-medium text-gray-500 uppercase">Alamat Lengkap</label>
          <textarea
            value={data.alamat}
            onChange={(e) => handleChange('alamat', e.target.value)}
            rows={2}
            className="w-full p-2.5 bg-gray-50 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
            placeholder="Jl. Merdeka No. 45, Jakarta Pusat"
          />
        </div>
      </div>

      {/* 3. INFO SURAT */}
      <div className="bg-white p-5 rounded-lg border border-gray-200 shadow-sm space-y-4">
        <h3 className="font-semibold text-lg text-gray-800 flex items-center gap-2 border-b pb-2">
          <FileType className="text-blue-600" size={20} /> Informasi Surat
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1">
            <label className="text-xs font-medium text-gray-500 uppercase">Judul Surat</label>
            <input
              type="text"
              value={data.judulSurat}
              onChange={(e) => handleChange('judulSurat', e.target.value.toUpperCase())}
              className="w-full p-2.5 bg-gray-50 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 font-bold"
            />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-medium text-gray-500 uppercase">Nomor Surat (Opsional)</label>
            <input
              type="text"
              value={data.nomorSurat}
              onChange={(e) => handleChange('nomorSurat', e.target.value)}
              className="w-full p-2.5 bg-gray-50 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
              placeholder="No: 001/SP/2024"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1">
            <label className="text-xs font-medium text-gray-500 uppercase">Tempat Surat</label>
            <div className="relative">
              <MapPin size={16} className="absolute left-3 top-3 text-gray-400" />
              <input
                type="text"
                value={data.tempatSurat}
                onChange={(e) => handleChange('tempatSurat', e.target.value)}
                className="w-full p-2.5 pl-9 bg-gray-50 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                placeholder="Jakarta"
              />
            </div>
          </div>
          <div className="space-y-1">
            <label className="text-xs font-medium text-gray-500 uppercase">Tanggal Surat</label>
             <div className="relative">
              <Calendar size={16} className="absolute left-3 top-3 text-gray-400" />
              <input
                type="date"
                value={data.tanggalSurat}
                onChange={(e) => handleChange('tanggalSurat', e.target.value)}
                className="w-full p-2.5 pl-9 bg-gray-50 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
        </div>
      </div>

      {/* 4. ISI PERNYATAAN */}
      <div className="bg-white p-5 rounded-lg border border-gray-200 shadow-sm space-y-4">
         <h3 className="font-semibold text-lg text-gray-800 flex items-center gap-2 border-b pb-2">
          <FileText className="text-blue-600" size={20} /> Isi Pernyataan
        </h3>
        <p className="text-sm text-gray-500 italic">
          Tips: Gunakan "Enter" untuk membuat paragraf baru. Halaman akan bertambah otomatis jika teks terlalu panjang.
        </p>
        <textarea
          value={data.isi}
          onChange={(e) => handleChange('isi', e.target.value)}
          rows={12}
          className="w-full p-4 bg-gray-50 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all text-sm leading-relaxed"
          placeholder="Tuliskan isi pernyataan Anda di sini..."
        />
      </div>

      {/* 5. LEGALITAS */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <TTDUpload 
          value={data.signatureUrl}
          onChange={(val) => handleChange('signatureUrl', val || '')}
        />
        <StampUpload 
          value={data.stampUrl}
          onChange={(val) => handleChange('stampUrl', val || '')}
        />
      </div>
    </div>
  );
};

export default FormInput;